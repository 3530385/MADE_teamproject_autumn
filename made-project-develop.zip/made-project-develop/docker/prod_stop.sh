docker-compose -f docker-compose.prod.yaml down -v -t 1
