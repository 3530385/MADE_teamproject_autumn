<template>
<v-app>
  <Navigation/>
  <slot/>
</v-app>
</template>