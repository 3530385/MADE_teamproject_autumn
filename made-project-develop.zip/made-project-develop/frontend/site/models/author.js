export class Author {
    constructor(id, name, org, gid, oid, orgid, history) {
        this._id = id;
        this.name = name;
        this.org = org;
        this.gid = gid;
        this.oid = oid;
        this.orgid = orgid;
        this.history = history;
    }
}